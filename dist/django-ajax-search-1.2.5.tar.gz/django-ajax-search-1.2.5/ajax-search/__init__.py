"A customizable AJAX-powered search for Django."


__version__ = '1.2.5'